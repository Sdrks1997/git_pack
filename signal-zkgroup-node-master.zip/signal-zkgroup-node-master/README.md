# zkgroup

Library for the Signal Private Group System.

Work in progress.  Subject to change without notice, use outside Signal not yet recommended.

